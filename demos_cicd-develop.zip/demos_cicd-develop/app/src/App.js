import './App.css';

function App() {
  return (
    <div className="App">
      <h1>
          GitHub Actions - Sesión 4
      </h1>
      <h2>Continuous Delivery con Azure</h2>
      <br/>
      <img src="yoda.jpg" alt="yoda"></img>
    </div>
  );
}

export default App;
